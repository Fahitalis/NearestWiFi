from kafka import KafkaConsumer, KafkaProducer
import json
import os
import time
import random

KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")

consumer = KafkaConsumer(
    'raw-location',
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest',
    enable_auto_commit=True
)

producer = KafkaProducer(
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

print("[SPARK] Listening to 'raw-location'")

for msg in consumer:
    location = msg.value
    print("[SPARK] Received:", location)

    lat, lon = location.get("lat"), location.get("lon")
    nearby_points = [{
        "device_id": location.get("device_id"),
        "lat": lat + random.uniform(-0.001, 0.001),
        "lon": lon + random.uniform(-0.001, 0.001),
        "timestamp": time.time()
    } for _ in range(3)]

    result = {"points": nearby_points}
    producer.send("nearest-points", result)
    print("[SPARK] Sent 3 nearby points")
