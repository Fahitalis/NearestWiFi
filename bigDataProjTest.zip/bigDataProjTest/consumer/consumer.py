from kafka import KafkaConsumer
from pymongo import MongoClient
import json
import os
import time

KAFKA_BOOTSTRAP_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

consumer = KafkaConsumer(
    'nearest-points',
    bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest',
    enable_auto_commit=True
)

mongo = MongoClient(MONGO_URI)
db = mongo.geo
db.points.create_index("timestamp", expireAfterSeconds=300)

print("[CONSUMER] Listening to 'nearest-points'")

for msg in consumer:
    data = msg.value
    for point in data.get("points", []):
        point["timestamp"] = time.time()
        db.points.insert_one(point)
        print(f"[CONSUMER] Saved point: {point}")
