from fastapi import FastAPI, Request
from kafka import KafkaProducer
from pymongo import MongoClient
import os
import json
import asyncio
import random
import time

app = FastAPI()

KAFKA_SERVERS = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092")
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

producer = KafkaProducer(
    bootstrap_servers=KAFKA_SERVERS,
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

mongo = MongoClient(MONGO_URI)
db = mongo.geo
db.points.create_index("timestamp", expireAfterSeconds=300)

@app.post("/location")
async def post_location(request: Request):
    data = await request.json()
    await asyncio.get_event_loop().run_in_executor(
        None, lambda: producer.send("raw-location", data)
    )
    return {"status": "ok"}

@app.get("/last-location")
def get_last_location(device_id: str):
    doc = db.points.find_one({"device_id": device_id}, sort=[("timestamp", -1)])
    if doc:
        doc["_id"] = str(doc["_id"])
    return doc or {}

@app.post("/generate-test")
def generate_random_point():
    lat = 55.75 + random.uniform(-0.01, 0.01)
    lon = 37.61 + random.uniform(-0.01, 0.01)
    data = {
        "device_id": f"test_{int(time.time())}",
        "lat": lat,
        "lon": lon
    }
    producer.send("raw-location", data)
    return {"sent": data}